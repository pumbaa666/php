<?php
session_start();
//ce script est appel� par l'animation flash. Prenez note que si vous instanciez une session ici (session_start(); ) elle sera diff�rente de celle de la session instanci�e par l'utilisateur affichant la page HTML contenant NAS Uploader. Vous ne pouvez donc pas acc�der � ses variables de session personnelles.

// Si l'utilisateur veut que ses images soient coll�es dans l'ordre o� il les envoie (et non par ordre alphabetique) il faut renommer les photos en ajoutant un nombre devant
$sortOrder = 'alpha';
if(isset($_GET['sortOrder']))
{
	if($_GET['sortOrder'] == 'sent')
		$sortOrder = 'sent';
} // TODO

// Cr�e un num�ro de fichier
require_once("getdata.php");
$num = getData();
setData($num+1); // todo faire le ++ dans le getData


// V�rifie l'existence de dossierup
if(isset($_GET['dossierup']))
	$save_path = "./uploads/".$_GET['dossierup'].'/';
else
{
	echo utf8_encode('Veuillez sp�cifier le dossier d\'upload');
	return;
}

if(isset($_FILES["Filedata"]))
{
	if($_FILES["Filedata"]['error'] == 0)
	{		
		$tabfile = explode('.',  $_FILES['Filedata']['name']);
		
		$dotPos = strrpos($_FILES['Filedata']['name'], ".");
		if($dotPos === false)
			$extfi = "";
		else
			$extfi = strtolower(substr($_FILES['Filedata']['name'], $dotPos));
		
		if(file_exists($save_path . $_FILES['Filedata']['name']))
			echo utf8_encode('Un fichier porte d�j� ce nom dans ce dossier');
		elseif(!in_array($extfi, array('.jpg','.jpeg','.gif','.png')))
			echo utf8_encode('N\'envoyez que des fichier jpg, jpeg, gif ou png');
		else
		{
			@mkdir($save_path,0777); 
			@chmod($save_path,0777); 
			if(@move_uploaded_file($_FILES["Filedata"]["tmp_name"], $save_path.$num.'_'.(($_FILES["Filedata"]["name"]))))
				echo utf8_encode('1');
			else
				echo utf8_encode('Erreur d\'�criture');
		}
	}
	else
	{
		switch ($_FILES["Filedata"]['error'])
		{
			case 1: echo 'Fichier trop volumineux'; break;
			case 2: echo 'Fichier trop volumineux'; break;
			case 3: echo 'Fichier incomplet'; break;
			case 4: echo 'Pas de fichier'; break;
			case 5: echo 'Erreur inconnue'; break;
			case 6: echo 'Erreur serveur'; break; //pas de dossier tmp
			case 7: echo utf8_encode('Erreur d\'�criture'); break;
			case 8: echo 'Extension incorrecte'; break;
			default: echo 'Erreur inconnue'; break;
		}
	}
}
else
	echo utf8_encode("Pas de fichiers envoy�s");

echo utf8_encode('.');
?>
