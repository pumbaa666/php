<?php
session_start();
$_SESSION['key'] = rand (12345,56789);
$_SESSION['num'] = 0;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<title>G�n�rateur de mosa�que</title>
	<link rel="stylesheet" href="css/common.css" type="text/css" media="screen" />
	<script language="JavaScript" type="text/javascript" src="Scripts/jsscript.js"></script>
	<script language="JavaScript" type="text/javascript" src="Scripts/swfobject.js"></script>
	<style type="text/css"></style>
</head>

<body>
Ce script vous permet de r�aliser un collage de plusieurs images en une seule.<br />
Concr�tement vous choisissez un lot d'image, vous rentrez les param�tres qui vous conviennent et le script vous fournira une image contenant une mosa�que de ce que vous lui avez envoy�.<br /><br />

Ne vous souciez pas de la taille des images que vous envoyez, le script les redimensionnera automatiquement<br /><br />

<b><u>Les param�tres</u></b><br />
	- <b>Largeur max : </b>Largeur maximale de chaque vignette<br />
	- <b>Hauteur max : </b>Hauteur maximale de chaque vignette<br />
	- <b>Nb images par colones : </b>Assez clair ^^<br />
	- <b>Gap horizontal : </b>Espacement horizontal entre 2 images<br />
	- <b>Gap vertical : </b>Espacement vertical entre 2 images<br />
	- <b>Couleur de fond : </b>Les vignettes seront coll�es sur une image unie. Vous choisissez ici la couleur de cette image en d�finissant les composantes Rouge, Verte, Bleue (entre 0 et 255)<br />
	- <b>Format de sortie : </b>Format de l'image finale<br />
Note : Toutes les tailles sont exprim�es en pixel.<br /><br />

		<form method = 'post' action = './generate.php' id = 'formParam' name = 'formParam' ENCTYPE='multipart/form-data'>
		<table border = '0' height = '30%'>
			<tr>
				<td width = '35%'>Largeur max</td><td><input name = 'widthMax' type = 'text' value = '120' size = '4' /></td>
				<td>Hauteur max</td><td><input name = 'heightMax' type = 'text' value = '140' size = '4' /></td>
			</tr>
			
			<tr>
				<td>Nb images par colones</td><td><input name = 'nbImgByColumn' type = 'text' value = '5' size = '4' /><td>
			</tr>
			
			<tr>
				<td>Gap horizontal</td><td><input name = 'widthGap' type = 'text' value = '5' size = '4' /></td>
				<td>Gap vertical</td><td><input name = 'heightGap' type = 'text' value = '5' size = '4' /></td>
			</tr>
			
			<tr>
				<td>Couleur de fond</td>
				<td>
					<script type="text/javascript" src="./Scripts/jscolor/jscolor.js"></script>
					<input name = 'color' class="color" value="AFC6DB">
				</td>
			</tr>
			
			<tr>
				<td>Format de sortie</td>
				<td><select name = 'format'>
					<option value = '2'>JPG</option>
					<option value = '1'>GIF</option>
					<option value = '3'>PNG</option>
				</select></td>
			</tr>

			<tr>
				<td>Ordre alphabetique</td><td><input type="radio" name="sortOrder" id="sortOrder" value="alphabetic" checked /></td>
				<td>Ordre d'envoi</td><td><input type="radio" name="sortOrder" id="sortOrder" value="sent" /></td>
			</tr>
			
			<input name = 'folder' type = 'hidden' />
		</table>
		</form>


	<form id="form_upload" name="form_upload" method="post" action="">
		<div style="color:red;">
			<pre>
			<?php
				if (isset ($_POST) && count($_POST) > 0 )
				{
					echo '<strong>Formulaire envoy� !</strong><br /><br />';
					print_r($_POST);
				}
			?>
			</pre>
		</div><br />

		<div id="mon_flash">
			Pour uploader, vous devez telecharger <a href="http://www.adobe.com/go/getflashplayer_fr" onclick="window.open(this.href); return false;"><strong>le player flash</strong></a>
		</div>
		
		<script type="text/javascript">
			function generateFolderName()
			{
				var timestamp = new Date().getTime();
				
				<?php
					echo "var ip = '".$_SERVER['REMOTE_ADDR']."'";
				?>
				
				var rnd = randomString(5);
				
				return (ip+"_"+timestamp+"_"+rnd);
			}
			
			function randomString(nbChar)
			{
				var str = "";
				for(var i = 0; i < nbChar; i++)
					str = str+Math.floor(Math.random()*10);
				return str;
			}
		
			// <![CDATA[
			var folderName = generateFolderName();
			document.formParam.folder.value = folderName;
			
			/*<?php
				$_SESSION['fileNumber'] = 0;
			?>
			
			for(i=0,i<=2,i++)
			{
				if(document.formParam.sortOrder[i].checked)
				{
					VarRecup=document.formParam.sortOrder[i].value;
				}
			}
			alert("radio = "+VarRecup);*/
			
			var so = new SWFObject("./applications/NasUploader15.swf", "nasuploader", "550", "400", "8");
			so.addParam ('FlashVars','varget=dossierup%3D'+folderName);
			//so.addParam ('FlashVars','varget=dossierup%3D'+folderName+'%26sortOrder%3Dsent');
			so.write("mon_flash");
			// ]]>
		</script>
		<br />
	</form>
	
	<br /><br /><b>Auteurs :</b><br />
	Formulaire + G�n�rateur d'image : <a href = 'mailto:pumbaa@net2000.ch'>Pumbaa</a><br />
	Librairie de manipulation d'image : <a href = 'http://mtodorovic.developpez.com/php/gd/'>GD</a><br />
	Syst�me d'upload de fichiers : <a href = 'http://www.nasuploader.com/'>NAS Uploader</a><br />
	S�lectionneur de couleur : <a href = 'http://jscolor.com/'>JS Color</a><br />
	<br /><a href = './code_source'>Code source</a>

</body>
</html>
