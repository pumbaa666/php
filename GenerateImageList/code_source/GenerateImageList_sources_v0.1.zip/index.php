<html>
<head><title>Generate Image List</title></head>

<body>
	<form method = 'post' action = 'upload.php' ENCTYPE='multipart/form-data'>
		<input type="submit" name="valider" value="Envoyer..."/><br />
		
		Largeur max : <input name = 'widthMax' type = 'text' value = '120' size = '4' />
		Hauteur max : <input name = 'heightMax' type = 'text' value = '140' size = '4' /><br/>
		
		Nb images par colones : <input name = 'nbImgByColumn' type = 'text' value = '5' size = '4' /><br/>
		
		Gap horizontal : <input name = 'widthGap' type = 'text' value = '5' size = '4' />
		Gap vertical : <input name = 'heightGap' type = 'text' value = '5' size = '4' /><br />
		
		Couleur de fond : 
		Rouge : <input name = 'red' type = 'text' value = '255' size = '4' />
		Vert : <input name = 'green' type = 'text' value = '255' size = '4' />
		Bleu : <input name = 'blue' type = 'text' value = '255' size = '4' /> <br />
		
		Format de sortie :
		<select name = 'format'>
			<option value = '2'>JPG</option>
			<option value = '1'>GIF</option>
			<option value = '3'>PNG</option>
		</select><br />
		
		<br />Images :<br />
		
<?php
$maxfiles = 100;
$maxsize = 2000000;
	echo 	'<input type="hidden" name="MAX_FILE_SIZE" value="'.$maxsize.'"/>';
		for($x=1; $x <= max($maxfiles,1); $x++)
			echo ' <input type="file" name="userfile[]" size="20"/><br/>';
	echo '</form>';
?>
		
		
	</form>
</body>
</html>