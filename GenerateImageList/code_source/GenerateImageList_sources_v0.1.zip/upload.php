<?php

	// Test si les param�tres ont �t� envoy�s
	if(!isset($_POST['widthMax']) || !isset($_POST['heightMax']) || !isset($_POST['nbImgByColumn']) /*|| !isset($_POST['widthGap']) || !isset($_POST['heightGap']) || !isset($_POST['red']) || !isset($_POST['green']) || !isset($_POST['blue'])*/)
	{
		header("Location:badParameters.php?message=Il manque des param�tres");
		return;
	}
	
	// Test si les param�tres sont num�riques
	if(!is_numeric($_POST['widthMax']) || !is_numeric($_POST['heightMax']) || !is_numeric($_POST['nbImgByColumn']) || !is_numeric($_POST['widthGap']) || !is_numeric($_POST['heightGap']) || !is_numeric($_POST['red']) || !is_numeric($_POST['green']) || !is_numeric($_POST['blue']))
	{
		header("Location:badParameters.php?message=Les param�tres doivent �tre des nombres");
		return;
	}
	
	// Test la plage de valeur admise par les param�tres
	if($_POST['widthMax'] <= 0 || $_POST['heightMax']  <= 0 || $_POST['nbImgByColumn'] <= 0 || $_POST['widthGap'] < 0 || $_POST['heightGap'] < 0 || $_POST['red'] < 0 || $_POST['green'] < 0 || $_POST['blue'] < 0)
	{
		header("Location:badParameters.php?message=Les nombres doivent �tre sup�rieurs � z�ro");
		return;
	}
	
	// Test la plage de valeur admise par les param�tres
	if($_POST['widthMax'] > 500 || $_POST['heightMax']  > 500 || $_POST['nbImgByColumn'] > 50 || $_POST['widthGap'] > 50 || $_POST['heightGap'] > 50 || $_POST['red'] > 255 || $_POST['green'] > 255 || $_POST['blue'] > 255)
	{
		header("Location:badParameters.php?message=X max < 500<br>Y max < 500<br>Le nombre d'images par colone < 50<br>X Gap < 50<br>Y Gap < 50<br>Red < 255<br>Green < 255<br>Blue < 255 /*<br>Alpha < 127*/");
		return;
	}

	// R�cup�ration des param�tres
	$widthMax = $_POST['widthMax']; // Largeur maximale d'une image
	$heightMax = $_POST['heightMax']; // Hauteur maximale d'une image
	$nbImgByColumn = $_POST['nbImgByColumn']; // Nombre maximum d'images par colone
	
	$widthGap = $_POST['widthGap']; // Espacement horizontal entre chaque lignes
	$heightGap = $_POST['heightGap']; // Espacement vertical entre chaque lignes
	
	$red = $_POST['red']; // Composante rouge de l'image de fond
	$green = $_POST['green']; // Composante verte de l'image de fond
	$blue = $_POST['blue']; // Composante bleue de l'image de fond

//===============================================================================
//
//  UPLOAD HTTP - Sub0 - 08/07/05
//	http://www.developpez.net/forums/d50059/php/langage/fichiers/upload-upload-erreur-envoi-multiple/#post341500
//
//===============================================================================
$maxfiles = 10;
$maxsize = 2000000;
$finaldir = 'upload_'.$_SERVER['REMOTE_ADDR']."_".time();
 
 
//===============================================================================
//  TRAITEMENT DU FORMULAIRE
//===============================================================================
if(isset($_POST['valider']))
{
	//=============================================================================
	//  TEST DU NOMBRE DE FICHIERS POSTES
	//=============================================================================
	$nbr = 0;
	for($x = 0; $x < $maxfiles; $x++)
		if(!empty($_FILES['userfile']['name'][$x]))
			$nbr++;
	if($nbr <= 0)
		die("Aucun fichier sp�cifi� !<br/>"); 
  
	//=============================================================================
	//  CREATION DE L'ARBORESCENCE POUR LE DOSSIER DESTINATION
	//=============================================================================
	if(!empty($finaldir))
	{ 
		if(substr($finaldir,strlen($finaldir)-1,1)=='/')
			$finaldir.='/'; 
		$dir=explode('/',$finaldir); 
		$finaldir=''; 
		for($x = 0; $x < count($dir); $x++)
		{	 
			$finaldir.=$dir[$x].'/'; 
			if(!@is_dir($finaldir))
				@mkdir($finaldir,0777); 
		} 
		if(!@is_dir($finaldir))
			die("Le dossier $finaldir est invalide !<br/>"); 
	} 
 
	//=============================================================================
	//  TELECHARGEMENT DES FICHIERS
	//=============================================================================
	for($x=1;$x<=$maxfiles;$x++)
	{
		$errorhttp=$_FILES['userfile']['error'][$x-1];
		$filenamehttp=$_FILES['userfile']['name'][$x-1];
		$typehttp=$_FILES['userfile']['type'][$x-1]; 
		$sizehttp=$_FILES['userfile']['size'][$x-1];
		$tmpfilehttp=$_FILES['userfile']['tmp_name'][$x-1];
		if(($errorhttp) and (!empty($filenamehttp)))
		{
			switch($errorhttp)
			{			
				case 1: echo "Erreur : Le fichier n�$x est trop grand !<br/>";break; 
				case 2: echo "Erreur : Le fichier n�$x est trop grand !<br/>";break; 
				case 3: echo "Erreur : Transfert du fichier n�$x interrompu !<br/>";break; 
				case 4: echo "Erreur : Le fichier n�$x est vide !<br/>";break; 
			} 
		}
		else
		{      
			if((!empty($filenamehttp))and($sizehttp>0))
			{
				if($sizehttp<=$maxsize)
				{
					if(@is_uploaded_file($tmpfilehttp))
					{
						if(@eregi('.php',$filenamehttp))
							$filenamehttp.='.txt'; 
						if(filesize($tmpfilehttp)==$sizehttp)
						{
							if(@move_uploaded_file($tmpfilehttp,$finaldir.$filenamehttp))
							{ 
								@chmod($filenamehttp,0777); 
								//echo "Fichier n�$x upload� : ".basename($filenamehttp)." (".round(max($sizehttp,1024)/1024)." ko)<br/>";
							}
							else
								echo "Erreur de t�l�chargement du fichier n�$x !<br/>"; 
						}
						else
							echo "Erreur de t�l�chargement du fichier n�$x !<br/>";
					}
					else
						echo "Erreur de t�l�chargement du fichier n�$x !<br/>"; 
				}
				else
					echo "Erreur : Le fichier n�$x est trop grand !<br/>"; 
			}
			//else
				//echo "Le fichier n�$x est introuvable ou vide !<br/>";
		}
	}

	require_once("generate.php");
	generate($widthMax, $heightMax, $nbImgByColumn, $widthGap, $heightGap, $red, $green, $blue, $finaldir);
}
?>