<?php
/**
	Auteur : Pumbaa
	E-Mail : pumbaa@net2000.ch (n'h�sitez pas � m'envoyer un email si vous avez des questions)
	
	Tuto : http://mtodorovic.developpez.com/php/gd/?page=sommaire
*/
function generate($widthMax, $heightMax, $nbImgByColumn, $widthGap, $heightGap, $red, $green, $blue, $folder)
{
	$dir = opendir($folder);

	$nbImages = 0;
	while($f = readdir($dir))
	{
		if(is_file($folder.$f))
		{
			$details = getimagesize($folder.$f);
			if($details[2] <= 0 || $details[2] > 3) // Ne traite que les images (voir http://mtodorovic.developpez.com/php/gd/?page=page_3#LIII-3.1 )
				continue;
			$images[$nbImages][0] = $folder.$f; // Sauve le nom de l'image
			$images[$nbImages][1] = $details[2]; // Sauve le type de l'image
			$nbImages++;
		}
	}
	closedir($dir);
	
	if($nbImages <= 0)
	{
		header("Location:badParameters.php?message=Aucun fichier d'image valide");
		return;
	}
	
	// Calcul la taille de l'image finale
	if($nbImages < $nbImgByColumn)
		$xTot = $nbImages * ($widthMax + $widthGap);
	else
		$xTot = $nbImgByColumn * ($widthMax + $widthGap);
	$yTot = ceil($nbImages / $nbImgByColumn) * ($heightMax + $heightGap);
	
	$destination = imagecreatetruecolor($xTot,$yTot); // Cr�ation d'une image de fond
	$couleur = imagecolorallocate($destination, $red, $green, $blue); // Cr�ation de la couleur
	imagefill($destination,0,0,$couleur); // Remplissage de l'image de fond en couleur
	
	$xLeft = 0;
	$yTop = 0;
	for($count = 0; $count < $nbImages; $count++) // On ouvre l'image source (chaque pochette)
	{
		switch($images[$count][1]) // S�lectionne la bonne fonction pour ouvrir l'image
		{
			case  1: $source = imagecreatefromgif($images[$count][0]); break;
			case  2: $source = imagecreatefromjpeg($images[$count][0]); break;
			case  3: $source = imagecreatefrompng($images[$count][0]); break;
			//case  4: $source = imagecreatefromswf($images[$count][0]); break;
			//case  5: $source = imagecreatefrompsd($images[$count][0]); break;
			//case  6: $source = imagecreatefrombmp($images[$count][0]); break;
			//case  7: $source = imagecreatefromtiff($images[$count][0]); break;
			//case  8: $source = imagecreatefromtiff($images[$count][0]); break;
			//case  9: $source = imagecreatefromjpc($images[$count][0]); break;
			//case 10: $source = imagecreatefromjp2($images[$count][0]); break;
			//case 11: $source = imagecreatefromjpx($images[$count][0]); break;
			//case 12: $source = imagecreatefromjb2($images[$count][0]); break;
			//case 13: $source = imagecreatefromswc($images[$count][0]); break;
			//case 14: $source = imagecreatefromiff($images[$count][0]); break;
			default : die("Format d'image non pris en charge : ".$images[$count][1]." / ".$images[$count][0]);
		}
		
		// Taille de l'image originale
		$x = imagesx($source);
		$y = imagesy($source);
		$ratioInit = $x / $y;
		
		// Calcul de la bonne taille finale, pour ne pas changer le ratio largeur / hauteur
		$newY = $heightMax;
		$newX = $newY * $ratioInit;

		// Redimensionnement
		$sourceMini = imagecreatetruecolor($newX,$newY); // Cr�ation d'une image truecolor de la taille d'une vignette
		imagecopyresampled($sourceMini, $source, 0, 0, 0, 0, $newX, $newY, $x, $y);

		// Nouvelle taille
		$x = imagesx($sourceMini);
		$y = imagesy($sourceMini);
		
		// Centre l'image
		$xAlign = ($widthMax - $x) / 2;
		$yAlign = ($heightMax - $y) / 2;
		
//		imagecopy($image_dest, $image_src, $dest_x, $dest_y, $src_x, $src_y, $src_largeur, $src_hauteur);
		imagecopy($destination, $sourceMini, ($widthMax + $widthGap) * $xLeft + $xAlign, ($heightMax + $heightGap) * $yTop + $yAlign, 0, 0, $x, $y); // Copie de la totalit� de la pochette sur l'image finale
		if(($count+1) % $nbImgByColumn == 0) // "Retour � la ligne"
		{
			$xLeft = 0;
			$yTop++;
		}
		else
			$xLeft++;
			
		imagedestroy($sourceMini); // Lib�ration de la m�moire
	}

	
	if(isset($_POST['format']))
		$format = $_POST['format'];
	else
		$format = 2; // jpeg par defaut
		
	$imageName = './'.$folder.'RESULT.';
	
	switch($format) // Affichage de l'image finale
	{
		case 1 :
			$imageName = $imageName."gif";
			header("Content-type: image/gif"); //Indispensable au bon fonctionnement des fonctions GD
			imagegif($destination, $imageName);
			break;
			
		case 3 :
			$imageName = $imageName."png";
			header("Content-type: image/png"); //Indispensable au bon fonctionnement des fonctions GD
			imagepng($destination, $imageName);
			break;
			
		default :
			$imageName = $imageName."jpg";
			header("Content-type: image/jpeg"); //Indispensable au bon fonctionnement des fonctions GD
			imagejpeg($destination, $imageName);
			break;
	}
	header("Location:download.php?url=".$imageName, false); // Renvoie sur la page pour DL l'image finale
	// TODO limitation par IP
	// TODO Upload d'un dossier complet

	imagedestroy($destination); // Lib�ration de la m�moire
}
?>