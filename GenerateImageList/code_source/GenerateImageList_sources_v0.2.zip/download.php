<?php
	if(!isset($_GET['url']))
		echo "Erreur, l'url de l'image n'est pas fournie";
	else
	{
		echo "Votre image est disponible ici : <a href = '".$_GET['url']."'>".$_GET['url']."</a> pendant 1h<br />";
		echo "<img src = '".$_GET['url']."' />";
	}
	echo "<br /><a href = 'index.php'>Retour</a>";
?>