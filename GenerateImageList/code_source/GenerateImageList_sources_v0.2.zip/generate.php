<?php
/**
	Auteur : Pumbaa
	E-Mail : pumbaa@net2000.ch (n'h�sitez pas � m'envoyer un email si vous avez des questions)
	
	Tuto GD : http://mtodorovic.developpez.com/php/gd/?page=sommaire
	FancyUpload : http://digitarald.de/project/fancyupload/
*/

	$error = checkPostParameters();
	if($error != "")
	{
		header("Location:badParameters.php?message=$error");
		return;
	}

	// R�cup�ration des param�tres
	$widthMax = $_POST['widthMax']; // Largeur maximale d'une image
	$heightMax = $_POST['heightMax']; // Hauteur maximale d'une image
	$nbImgByColumn = $_POST['nbImgByColumn']; // Nombre maximum d'images par colone
	
	$widthGap = $_POST['widthGap']; // Espacement horizontal entre chaque lignes
	$heightGap = $_POST['heightGap']; // Espacement vertical entre chaque lignes
	
	$red = $_POST['red']; // Composante rouge de l'image de fond
	$green = $_POST['green']; // Composante verte de l'image de fond
	$blue = $_POST['blue']; // Composante bleue de l'image de fond
	
	$givenFileName = mb_split("\|",$_POST['everyFiles']);

	$folder = $_POST['folder']."/";

	$nbImages = 0;
	$nbFiles = sizeof($givenFileName);
	for($i = 0; $i < $nbFiles; $i++)
	{
		$filePathName = $folder.$givenFileName[$i];
		if(is_file($folder.$givenFileName[$i]))
		{
			$details = getimagesize($filePathName);
			if($details[2] <= 0 || $details[2] > 3) // Ne traite que les images (voir http://mtodorovic.developpez.com/php/gd/?page=page_3#LIII-3.1 )
				continue;
			$images[$nbImages][0] = $filePathName; // Sauve le nom de l'image
			$images[$nbImages][1] = $details[2]; // Sauve le type de l'image
			$nbImages++;
		}
	}

	if($nbImages <= 0)
	{
		header("Location:badParameters.php?message=Aucun fichier d'image valide dans le dossier ".$folder);
		return;
	}
	
	// Calcul la taille de l'image finale
	if($nbImages < $nbImgByColumn)
		$widthTotal = $nbImages * ($widthMax + $widthGap);
	else
		$widthTotal = $nbImgByColumn * ($widthMax + $widthGap);
	$heightTotal = ceil($nbImages / $nbImgByColumn) * ($heightMax + $heightGap);
	
	$destination = imagecreatetruecolor($widthTotal,$heightTotal); // Cr�ation d'une image de fond
	$couleur = imagecolorallocate($destination, $red, $green, $blue); // Cr�ation de la couleur
	imagefill($destination,0,0,$couleur); // Remplissage de l'image de fond en couleur
	
	$wLeft = 0;
	$hTop = 0;
	for($count = 0; $count < $nbImages; $count++) // On ouvre l'image source (chaque pochette)
	{
		switch($images[$count][1]) // S�lectionne la bonne fonction pour ouvrir l'image
		{
			case  1: $source = imagecreatefromgif($images[$count][0]); break;
			case  2: $source = imagecreatefromjpeg($images[$count][0]); break;
			case  3: $source = imagecreatefrompng($images[$count][0]); break;
			default : die("Format d'image non pris en charge : ".$images[$count][1]." / ".$images[$count][0]);
		}
		
		// Taille de l'image originale
		$w = imagesx($source);
		$h = imagesy($source);
		
		// Calcul de la bonne taille finale, pour ne pas changer le ratio largeur / hauteur
		if($w > $h) // Si $w > y$...
		{
			$ratioInit = $h / $w;
			$newWidth = $widthMax; // ... $newWidth prendra la taille maximale --> $widthMax ...
			$newHeight = $newWidth * $ratioInit; // .. et $newHeight sera adapt� en cons�quence, pour garder les proportions
		}
		else
		{
			$ratioInit = $w / $h;
			$newHeight = $heightMax;
			$newWidth = $newHeight * $ratioInit;
		}

		// Redimensionnement
		$sourceMini = imagecreatetruecolor($newWidth,$newHeight); // Cr�ation d'une image truecolor de la taille d'une vignette
		imagecopyresampled($sourceMini, $source, 0, 0, 0, 0, $newWidth, $newHeight, $w, $h);

		// Nouvelle taille
		$w = imagesx($sourceMini);
		$h = imagesy($sourceMini);
		
		// Centre l'image
		$wAlign = ($widthMax - $w) / 2;
		$hAlign = ($heightMax - $h) / 2;
		
//		imagecopy($image_dest, $image_src, $dest_x, $dest_y, $src_x, $src_y, $src_largeur, $src_hauteur);
		imagecopy($destination, $sourceMini, ($widthMax + $widthGap) * $wLeft + $wAlign, ($heightMax + $heightGap) * $hTop + $hAlign, 0, 0, $w, $h); // Copie de la totalit� de la pochette sur l'image finale
		if(($count+1) % $nbImgByColumn == 0) // "Retour � la ligne"
		{
			$wLeft = 0;
			$hTop++;
		}
		else
			$wLeft++;
			
		imagedestroy($sourceMini); // Lib�ration de la m�moire
	}

	
	if(isset($_POST['format']))
		$format = $_POST['format'];
	else
		$format = 2; // jpeg par defaut
		
	$imageName = './results/'.'RESULT_'.$_SERVER['REMOTE_ADDR']."_".randomString(10).'.';
	
	switch($format) // Affichage de l'image finale
	{
		case 1 :
			$imageName = $imageName."gif";
			header("Content-type: image/gif"); //Indispensable au bon fonctionnement des fonctions GD
			imagegif($destination, $imageName);
			break;
			
		case 3 :
			$imageName = $imageName."png";
			header("Content-type: image/png"); //Indispensable au bon fonctionnement des fonctions GD
			imagepng($destination, $imageName);
			break;
			
		default :
			$imageName = $imageName."jpg";
			header("Content-type: image/jpeg"); //Indispensable au bon fonctionnement des fonctions GD
			imagejpeg($destination, $imageName);
			break;
	}
	header("Location:download.php?url=".$imageName, false); // Renvoie sur la page pour DL l'image finale
	// TODO limitation par IP

	imagedestroy($destination); // Lib�ration de la m�moire
	
function randomString($nbChar)
{
	$str = "";
	for($i = 0; $i < $nbChar; $i++)
		$str = $str.rand(0,9);
	return $str;
}

function checkPostParameters()
{
	$tabValue = array(
						"widthMax" => array("Largeur max", 1, 500) ,
						"heightMax" => array("Hauteur max", 1, 500) ,
						"nbImgByColumn" => array("Nombre d'image par colone", 1, 25) ,
						"widthGap" => array("Gap horizontal", 0, 50) ,
						"heightGap" => array("Gap vertical", 0, 50) ,
						"red" => array("Rouge", 0, 255) ,
						"green" => array("Vert", 0, 255) ,
						"blue" => array("Bleu", 0, 255)
					 );
	$errorMsg = "";
	
	foreach($tabValue as $key => $value)
	{
		$humanName = $value[0];
		$minValue = $value[1];
		$maxValue = $value[2];

		if(!isset($_POST[$key]))
			$errorMsg = $errorMsg."Il faut donner une valeur pour $humanName<br />";
		elseif(!is_numeric($_POST[$key]))
			$errorMsg = $errorMsg."$humanName doit �tre un nombre<br />";
		elseif($_POST[$key] < $minValue)
			$errorMsg = $errorMsg."$humanName doit �tre plus grand que $minValue<br />";
		elseif($_POST[$key] > $maxValue)
			$errorMsg = $errorMsg."$humanName doit �tre plus petit que $maxValue<br />";
	}
	if(!isset($_POST['folder']))
		$errorMsg = $errorMsg."Il faut donner une valeur pour Le chemin du dossier d'upload<br />";
	
	return $errorMsg;
}
?>