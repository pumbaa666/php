<html>
<head>
	<title>G�n�rateur de mosa�que</title>
	<link rel="stylesheet" href="css/common.css" type="text/css" media="screen" />
	<script type="text/javascript" src="build.js"></script>
	<script type="text/javascript" src="swiff/Swiff.Base.js"></script>
	<script type="text/javascript" src="swiff/Swiff.Uploader.js"></script>
	<script type="text/javascript" src="js/FancyUpload.js"></script>
	<style type="text/css">

		/**
		 * You don't need this css part, scroll down ;)
		 */

		.halfsize
		{
			width:					48%;
			margin-right:			5px;
			float:					left;
		}
		form fieldset
		{
			border:					none;
			border-top:				1px solid #888;
			margin:					1em 0.5em 1em 0;
			padding:				1em 0;
		}

		form legend
		{
			font-weight:			bold;
			font-size:				1.2em;
			color:					#888;
			margin:					auto;
			margin-left:			0;
			padding:				0 .25em 0 0;
		}
		label
		{
			width:					10em;
			float:					left;
			padding:				.2em .8em 0 0;
			margin-right:			.4em;
			text-align:				right;
			font-size:				1.1em;
		}
		label.error
		{
			color:					#ff0000;
		}

		label span
		{
			display:				block;
			color:					#888;
			font-size:				0.85em;
			margin-bottom:			0.5em;
		}
		form div.label,
		form div.note,
		form div.footer
		{
			clear:					both;
			margin:					1em 0 0 0;
			padding:				0.1em 0.3em;
		}

		form div.note
		{
			margin-left:			.5em;
		}
		input,
		button,
		select
		{
			width:					10em;
		}
		input.submit
		{
			font-weight:			bold;
			color:					#333;
			width:					auto;
			padding-right:			6px;
			padding-left:			6px;
		}


		/**
		 * Thats the basic css needed for the upload bars
		 */

		.photoupload-queue
		{
			list-style:				none;
		}
		.photoupload-queue li
		{
			background:				url(images/photo_upload.png) no-repeat 0 5px;
			padding:				5px 0 5px 22px;
		}

		.photoupload-queue .queue-file
		{
			font-weight:			bold;
		}

		.photoupload-queue .queue-size
		{
			color:					#aaa;
			margin-left:			1em;
			font-size:				0.9em;
		}

		.photoupload-queue .queue-loader
		{
			position:				relative;
			margin:					3px 15px;
			font-size:				0.9em;
			background-color:		#ddd;
			color:					#fff;
			border:					1px inset #ddd;
		}
		.photoupload-queue .queue-subloader
		{
			text-align:				center;
			position:				absolute;
			background-color:		#81B466;
			height:					100%;
			width:					0%;
			left:					0;
			top:					0;
		}

		.photoupload-queue .input-delete
		{
			width:					16px;
			height:					16px;
			background:				url(images/delete.png) no-repeat 0 0;
			text-decoration:		none;
			border:					none;
			float:					right;
		}
	</style>

	<script type="text/javascript">
		//<![CDATA[

		/**
		 * Sample Data
		 */

		window.addEvent('load', function()
		{
			/**
			 * We take the first input with this class we can find ...
			 */
			var input = $('photoupload-filedata-1');

			/**
			 * Simple and easy
			 * 
			 * swf: the path to the swf
			 * container: the object is embedded in this container (default: document.body)
			 * 
			 * NOTE: container is only used for the first uploader u create, all others depend
			 * on the same swf in that container, so the container option for the other uploaders
			 * will be ignored.
			 * 
			 */
			var uplooad = new FancyUpload(input, {
				swf: 'swiff/Swiff.Uploader.swf',
				queueList: 'photoupload-queue',
				container: $E('h1')
			});
			
			uplooad.addEvent('onAllComplete', function()
			{
				var everyFile = "";
				for(var i = 0; i < uplooad.fileList.length; i++)
					everyFile = everyFile+"|"+uplooad.fileList[i].name;
				document.formParam.everyFiles.value = everyFile;
				document.formParam.submit();
			});
			
		});

		//]]>
	</script>

</head>
<body>

	<div id="container">
Ce script vous permet de r�aliser un collage de plusieurs images en une seule.<br />
Concr�tement vous choisissez un lot d'image, vous rentrez les param�tres qui vous conviennent et le script vous fournira une image contenant une mosa�que de ce que vous lui avez envoy�.<br /><br />

Ne vous souciez pas de la taille des images que vous envoyez, le script les redimensionnera automatiquement<br /><br />

<b><u>Les param�tres</u></b><br />
	- <b>Largeur max : </b>Largeur maximale de chaque vignette<br />
	- <b>Hauteur max : </b>Hauteur maximale de chaque vignette<br />
	- <b>Nb images par colones : </b>Assez clair ^^<br />
	- <b>Gap horizontal : </b>Espacement horizontal entre 2 images<br />
	- <b>Gap vertical : </b>Espacement vertical entre 2 images<br />
	- <b>Couleur de fond : </b>Les vignettes seront coll�es sur une image unie. Vous choisissez ici la couleur de cette image en d�finissant les composantes Rouge, Verte, Bleue (entre 0 et 255)<br />
	- <b>Format de sortie : </b>Format de l'image finale<br />
Note : Toutes les tailles sont exprim�es en pixel.<br /><br />

		<form method = 'post' action = './generate.php' name = 'formParam' ENCTYPE='multipart/form-data'>
		<table border = '0' height = '30%'>
			<tr>
				<td width = '35%'>Largeur max</td><td><input name = 'widthMax' type = 'text' value = '120' /></td>
				<td>Hauteur max</td><td><input name = 'heightMax' type = 'text' value = '140' size = '4' /></td>
			</tr>
			
			<tr>
				<td>Nb images par colones</td><td><input name = 'nbImgByColumn' type = 'text' value = '5' size = '4' /><td>
			</tr>
			
			<tr>
				<td>Gap horizontal</td><td><input name = 'widthGap' type = 'text' value = '5' size = '4' /></td>
				<td>Gap vertical</td><td><input name = 'heightGap' type = 'text' value = '5' size = '4' /></td>
			</tr>
			
			<tr>
				<td>Couleur de fond</td>
				<td>Rouge<br /><input name = 'red' type = 'text' value = '255' size = '4' /></td>
				<td>Vert<br /><input name = 'green' type = 'text' value = '255' size = '4' /></td>
				<td>Bleu<br /><input name = 'blue' type = 'text' value = '255' size = '4' /></td>
			</tr>
			
			<tr>
				<td>Format de sortie</td>
				<td><select name = 'format'>
					<option value = '2'>JPG</option>
					<option value = '1'>GIF</option>
					<option value = '3'>PNG</option>
				</select></td>
			</tr>
			
			<input name = 'folder' type = 'hidden' />
			<input name = 'everyFiles' type = 'hidden' />
		</table>
		</form>
	
		<form action="upload.php" method="post" id="photoupload2" name = "formUpload" enctype="multipart/form-data">
		
			<div class="halfsize">
				<fieldset>
					<legend>S�lectionnez vos images</legend>

					<div class="label emph">
						<input type="file" name="Filedata" id="photoupload-filedata-1" />
						<input type="submit" class="submit" id="profile-submit-2" value="G�N�RER" onclick='cliquer()'/>
					</div>

				</fieldset>
			</div>
			<div class="halfsize">
				<fieldset>
					<legend>Images � charger</legend>

					<ul class="photoupload-queue" id="photoupload-queue">
						<li style="display: none" />
					</ul>
				</fieldset>
			</div>

			<div class="clear"></div>
		<input name = 'folder' type = 'hidden' />
		</form>
		
	</div>
	<br /><br />Auteur : <a href = 'mailto:pumbaa@net2000.ch'>Pumbaa</a>
	<br /><a href = './code_source'>Code source</a>
	<script src="js/urchin.js" type="text/javascript"></script>
	<script type="text/javascript">
	
	function cliquer()  
	{
		var folderName = generateFolderName();
		document.formParam.folder.value = folderName;
	}

	function generateFolderName()
	{
		<?php
			echo "var ip = '".$_SERVER['REMOTE_ADDR']."';";
		?>
		return ("upload_"+ip);
		/*var timestamp = new Date().getTime();
		
		<?php
			echo "var ip = '".$_SERVER['REMOTE_ADDR']."'";
		?>
		
		var rnd = randomString(5);
		
		return (ip+"_"+timestamp+"_"+rnd);*/
	}
	
	function randomString(nbChar)
	{
		var str = "";
		for(var i = 0; i < nbChar; i++)
			str = str+Math.floor(Math.random()*10);
		return str;
	}
	

	
	_uacct = "UA-601848-2";
	urchinTracker();
	</script>
</body>
</html>