<?php
function checkPostParameters()
{
	$tabValue = array(
						"widthMax" => array("Largeur max", 1, 500) ,
						"heightMax" => array("Hauteur max", 1, 500) ,
						"nbImgByColumn" => array("Nombre d'image par colone", 1, 25) ,
						"widthGap" => array("Gap horizontal", 0, 50) ,
						"heightGap" => array("Gap vertical", 0, 50) ,
						"red" => array("Rouge", 0, 255) ,
						"green" => array("Vert", 0, 255) ,
						"blue" => array("Bleu", 0, 255)
					 );
	$errorMsg = "";
	
	foreach($tabValue as $key => $value)
	{
		$humanName = $value[0];
		$minValue = $value[1];
		$maxValue = $value[2];

		if(!isset($_POST[$key]))
			$errorMsg = $errorMsg."Il faut donner une valeur pour $humanName<br />";
		elseif(!is_numeric($_POST[$key]))
			$errorMsg = $errorMsg."$humanName doit �tre un nombre<br />";
		elseif($_POST[$key] <= 0)
			$errorMsg = $errorMsg."$humanName doit �tre plus grand que $minValue<br />";
		elseif($_POST[$key] > 500)
			$errorMsg = $errorMsg."$humanName doit �tre plus petit que $maxValue<br />";
	}
	if(!isset($_POST['folder']))
		$errorMsg = $errorMsg."Il faut donner une valeur pour Le chemin du dossier d'upload<br />";
	
	return $errorMsg;

}
if($_POST)
	checkPostParameters();
?>
<form method = 'POST'>
	<input type = 'text' name = 'widthMax' />
	<input type = 'submit' />
</form>