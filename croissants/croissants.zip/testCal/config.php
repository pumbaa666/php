<?php
// Tableau pour le noms des months
$months = array();
$months[1] = "Janvier";
$months[2] = "F�vrier";
$months[3] = "Mars";
$months[4] = "Avril";
$months[5] = "Mai";
$months[6] = "Juin";
$months[7] = "Juillet";
$months[8] = "Ao�t";
$months[9] = "Septembre";
$months[10] = "Octobre";
$months[11] = "Novembre";
$months[12] = "D�cembre";

// Tableau pour le noms des days
$days = array();
$days[1] = "Lu";
$days[2] = "Ma";
$days[3] = "Me";
$days[4] = "Je";
$days[5] = "Ve";
$days[6] = "Sa";
$days[7] = "Di";
?>