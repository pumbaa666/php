<?php
	htmlHeader();
	echo "En chantier..... (je m'appel Lo�c)";
?>
<?php
	htmlFooter();
?>