<head><link rel='stylesheet' type='text/css' href='css/style.css'></head>
<?php
	session_start();
	require_once("fonction.php");
	isAuthorized();
	htmlHeader();

	echo "<div id = 'menu'>";
		include("menu.php");
	echo "</div>";

	if(isset($_GET['error']))
	{
		echo "<div id = 'message_error'>";
			echo $_GET['error'];
		echo "</div>";
	}

	if(isset($_GET['message']))
	{
		echo "<div id = 'message_ok'>";
			echo $_GET['message'];
		echo "</div>";
	}
	
	if(isset($_GET['page']))
	{
		echo "<div id = 'main'>";
			@include($_GET['page'].".php");
		echo "</div>";
	}

		
	echo "<div id = 'footer'>";
		if(date('w', time()) == 5 || false)
			include("croissantTime.php");

		$admin = "";
		if(isAdmin())
			$admin = " (admin)";
		echo "Logg� en tant que ".$_SESSION['userId']."$admin";
	echo "</div>";
	
	htmlFooter();
?>