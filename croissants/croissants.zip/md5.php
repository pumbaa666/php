<?php
echo md5("password1");
?>